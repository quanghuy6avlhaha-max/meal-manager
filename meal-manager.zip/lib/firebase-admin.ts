import * as admin from "firebase-admin";
import serviceAccount from "../meal-manager-6cd54-c9377-firebase-adminsdk-fbsvc-10e04a2551.json";

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
  });
}

export const adminAuth = admin.auth();
export const adminDb = admin.firestore();