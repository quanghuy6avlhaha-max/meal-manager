import {
  collection,
  getDocs,
} from "firebase/firestore";

import { db } from "./firebase";

export interface UserData {
  id: string;
  username: string;
  fullName: string;
  role: string;
}

export async function getUsers() {
  const snapshot = await getDocs(collection(db, "users"));

  const users: UserData[] = [];

  snapshot.forEach((doc) => {
    users.push({
      id: doc.id,
      ...(doc.data() as Omit<UserData, "id">),
    });
  });

  users.sort((a, b) => {
    if (a.role === "admin") return -1;
    if (b.role === "admin") return 1;

    return a.username.localeCompare(b.username);
  });

  return users;
}