"use client";

import { useState } from "react";

type Props = {
  date: string;
  close: () => void;
  save: (meals: string[]) => void;
  initialMeals: string[];
};

export default function MealPopup({
  date,
  close,
  save,
  initialMeals,
}: Props) {

  const [meals, setMeals] = useState<string[]>(initialMeals);


  const toggleMeal = (meal: string) => {

    if (meals.includes(meal)) {

      setMeals(
        meals.filter((item) => item !== meal)
      );

    } else {

      setMeals([
        ...meals,
        meal
      ]);

    }

  };


  const handleSave = () => {
    save(meals);
    close();
  };


  return (
    <div className="fixed inset-0 bg-black/40 flex items-end justify-center z-50">

      <div className="bg-white w-full rounded-t-3xl p-6">


        <h2 className="text-xl font-bold mb-5">
          📅 {date}
        </h2>


        <div className="space-y-4">


          <button
            onClick={() => toggleMeal("Sáng")}
            className={`
              w-full p-4 rounded-xl text-left
              ${
                meals.includes("Sáng")
                  ? "bg-green-100"
                  : "bg-gray-100"
              }
            `}
          >
            ☀️ Bữa sáng
          </button>



          <button
            onClick={() => toggleMeal("Trưa")}
            className={`
              w-full p-4 rounded-xl text-left
              ${
                meals.includes("Trưa")
                  ? "bg-green-100"
                  : "bg-gray-100"
              }
            `}
          >
            🍱 Bữa trưa
          </button>



          <button
            onClick={() => toggleMeal("Tối")}
            className={`
              w-full p-4 rounded-xl text-left
              ${
                meals.includes("Tối")
                  ? "bg-green-100"
                  : "bg-gray-100"
              }
            `}
          >
            🌙 Bữa tối
          </button>


        </div>



        <button
          onClick={handleSave}
          className="
            mt-6
            w-full
            bg-green-600
            text-white
            py-3
            rounded-xl
            font-semibold
          "
        >
          Lưu báo cơm
        </button>


      </div>

    </div>
  );
}