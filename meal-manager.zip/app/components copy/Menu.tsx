"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { logout } from "@/lib/auth";

export default function Menu() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  return (
    <div className="relative">

      <div className="h-16 bg-white shadow-sm flex items-center justify-between px-5">
        <div className="font-bold text-lg text-green-600">
          Báo cơm
        </div>

        <button
          onClick={() => setOpen(!open)}
          className="text-gray-500 text-2xl"
        >
          ☰
        </button>
      </div>

      {open && (
        <>
          {/* Lớp nền để bấm ra ngoài sẽ đóng menu */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setOpen(false)}
          />

          <div className="absolute right-5 top-16 bg-white shadow-xl rounded-xl p-2 w-56 z-50 border">

            <button
              onClick={() => {
                setOpen(false);
                router.push("/dashboard");
              }}
              className="w-full text-left px-3 py-3 rounded-lg hover:bg-gray-100"
            >
              🏠 Trang chủ
            </button>

            <button
              onClick={() => {
                setOpen(false);
                router.push("/admin");
              }}
              className="w-full text-left px-3 py-3 rounded-lg hover:bg-gray-100"
            >
              👤 Quản lý tài khoản
            </button>

            <hr className="my-2" />

            <button
              onClick={async () => {
                await logout();
                window.location.href = "/login";
              }}
              className="w-full text-left px-3 py-3 rounded-lg hover:bg-red-50 text-red-600"
            >
              🚪 Đăng xuất
            </button>

          </div>
        </>
      )}

    </div>
  );
}