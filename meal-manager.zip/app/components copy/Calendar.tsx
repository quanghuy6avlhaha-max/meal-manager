"use client";

import { useState, useEffect } from "react";
import MealPopup from "./MealPopup";

type MealData = {
  [date: string]: string[];
};

export default function Calendar() {

  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const [mealData, setMealData] = useState<MealData>({});
useEffect(() => {

  const saved =
    localStorage.getItem("mealData");


  if (saved) {

    setMealData(
      JSON.parse(saved)
    );

  }

}, []);

  const today = new Date();

  const year = today.getFullYear();
  const month = today.getMonth();


  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();


  const weekDays = [
    "T2",
    "T3",
    "T4",
    "T5",
    "T6",
    "T7",
    "CN",
  ];


  const blanks = firstDay === 0 ? 6 : firstDay - 1;



  const saveMeal = (meals: string[]) => {

  if (!selectedDate) return;


  const newData = {

    ...mealData,

    [selectedDate]: meals,

  };


  setMealData(newData);


  localStorage.setItem(
    "mealData",
    JSON.stringify(newData)
  );

};



  return (

    <div className="mt-5 bg-white rounded-3xl p-5 shadow">


      <h2 className="text-xl font-bold text-gray-800 mb-4">
        Tháng {month + 1}/{year}
      </h2>



      <div className="grid grid-cols-7 gap-2 mb-3">

        {weekDays.map((day) => (

          <div
            key={day}
            className="text-center text-sm text-gray-500 font-medium"
          >
            {day}
          </div>

        ))}

      </div>




      <div className="grid grid-cols-7 gap-2">


        {Array.from({ length: blanks }).map((_, index) => (

          <div key={index}></div>

        ))}




        {Array.from({ length: daysInMonth }).map((_, index) => {


          const day = index + 1;

          const date =
            `${day}/${month + 1}/${year}`;


          const isReported =
            mealData[date]?.length > 0;



          return (

            <button

              key={day}

              onClick={() =>
                setSelectedDate(date)
              }

              className={`
                aspect-square
                rounded-xl
                font-semibold
                transition

                ${
                  isReported
                  ? "bg-green-500 text-white"
                  : "bg-gray-100 text-gray-700"
                }

              `}

            >

              {day}


            </button>

          );


        })}



      </div>




      {selectedDate && (

  <MealPopup

    date={selectedDate}

    close={() =>
      setSelectedDate(null)
    }

    save={saveMeal}

    initialMeals={
      mealData[selectedDate] || []
    }

  />

)}



    </div>

  );

}