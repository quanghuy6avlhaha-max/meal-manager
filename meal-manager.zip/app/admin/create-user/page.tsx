"use client";

import { useState } from "react";

export default function CreateUser() {
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("123456");

  return (
    <div className="max-w-xl mx-auto">

      <h1 className="text-3xl font-bold text-gray-800 mb-2">
        Thêm tài khoản
      </h1>

      <p className="text-gray-500 mb-8">
        Tạo tài khoản mới
      </p>

      <div className="bg-white rounded-2xl shadow p-6">

        <div className="mb-5">

          <label className="block mb-2 font-medium">
            Username
          </label>

          <input
            value={username}
            onChange={(e) =>
              setUsername(e.target.value)
            }
            className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
            placeholder="nam01"
          />

        </div>

        <div className="mb-5">

          <label className="block mb-2 font-medium">
            Họ và tên
          </label>

          <input
            value={fullName}
            onChange={(e) =>
              setFullName(e.target.value)
            }
            className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
            placeholder="Nguyễn Văn A"
          />

        </div>

        <div className="mb-8">

          <label className="block mb-2 font-medium">
            Mật khẩu
          </label>

          <input
            type="text"
            inputMode="numeric"
            value={password}
            onChange={(e) =>
              setPassword(e.target.value.replace(/\D/g, ""))
            }
            className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          />

        </div>

        <div className="flex gap-3">

          <button
            className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold"
          >
            Tạo tài khoản
          </button>

          <button
            onClick={() => history.back()}
            className="flex-1 border rounded-xl py-3 font-semibold"
          >
            Quay lại
          </button>

        </div>

      </div>

    </div>
  );
}