"use client";

import { useEffect, useState } from "react";
import { getUsers, UserData } from "@/lib/users";

export default function Admin() {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    try {
      const data = await getUsers();
      setUsers(data);
    } catch (error) {
      console.error(error);
      alert("Không thể tải danh sách tài khoản.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto">

      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">
            Quản lý tài khoản
          </h1>

          <p className="text-gray-500 mt-1">
            Danh sách tài khoản sử dụng hệ thống
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow p-4 mb-4">
        <input
          type="text"
          placeholder="Tìm Username..."
          className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
        />
      </div>

      <div className="mb-4">
        <button
          onClick={() => {
            window.location.href = "/admin/create-user";
          }}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold"
        >
          + Thêm tài khoản
        </button>
      </div>

      <div className="mb-4 text-gray-600 font-medium">
        Tổng số tài khoản: {users.length}
      </div>

      <div className="bg-white rounded-2xl shadow overflow-hidden">

        <table className="w-full">

          <thead className="bg-green-600 text-white">
            <tr>
              <th className="w-12 text-center p-3">STT</th>
              <th className="text-left p-3">Username</th>
              <th className="text-left p-3">Họ và tên</th>
              <th className="w-16 text-center p-3"></th>
            </tr>
          </thead>

          <tbody>

            {loading ? (

              <tr>
                <td colSpan={4} className="text-center p-6">
                  Đang tải...
                </td>
              </tr>

            ) : users.length === 0 ? (

              <tr>
                <td colSpan={4} className="text-center p-6">
                  Chưa có tài khoản.
                </td>
              </tr>

            ) : (

              users.map((user, index) => (
                <tr
                  key={user.id}
                  className="border-b"
                >
                  <td className="text-center p-3">
                    {index + 1}
                  </td>

                  <td className="p-3">
                    {user.username}
                  </td>

                  <td className="p-3">
                    {user.fullName}
                  </td>

                  <td className="text-center p-3">
                    <button className="text-blue-600 hover:text-blue-800 text-lg">
                      ✏️
                    </button>
                  </td>
                </tr>
              ))

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}