import Calendar from "../components/Calendar";
import Menu from "../components/Menu";

export default function Home() {
  return (
    
    <main className="min-h-screen bg-gray-100 pb-20">
      <Menu />
      
      <div className="px-4 pt-4">
        <h1 className="text-2xl font-bold text-gray-800">
          🍱 Báo cơm
        </h1>

        <p className="text-gray-500 mt-1">
          Chọn ngày và đăng ký suất ăn
        </p>

        <Calendar />
      </div>
    </main>
  );
}