"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { login } from "@/lib/auth";
export default function Login() {

  const router = useRouter();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
const handleLogin = async () => {
  try {
    await login(username, password);
    router.push("/dashboard");
  } catch {
    alert("Tên đăng nhập hoặc mật khẩu không đúng!");
  }
};
  return (
    <main className="min-h-screen bg-gray-100 flex items-center justify-center px-6">

      <div className="w-full max-w-sm bg-white rounded-3xl shadow-lg p-8">

        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🍱</div>

          <h1 className="text-2xl font-bold text-gray-800">
            Meal Manager
          </h1>

          <p className="text-gray-500 mt-2">
            Đăng nhập để báo cơm
          </p>
        </div>

        <div className="space-y-5">

          <div>
            <label className="block text-sm font-medium mb-2">
              Tên đăng nhập
            </label>

          <input
            type="text"
            placeholder="Nhập tên đăng nhập"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Mật khẩu
            </label>

          <input
            type="password"
            placeholder="Nhập mật khẩu"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          />
          </div>

          <button
  onClick={handleLogin}
  className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700"
>
  Đăng nhập
</button>

        </div>

      </div>

    </main>
  );
}